#ifndef _headers_INCLUDED_
#define _headers_INCLUDED_

#pragma used+

#include <mega16.h>
#include <delay.h>
#include <alcd.h>
#include <stdio.h>
#include <string.h>
#include <source.h>
extern char data_key[];


#pragma used-

#endif

