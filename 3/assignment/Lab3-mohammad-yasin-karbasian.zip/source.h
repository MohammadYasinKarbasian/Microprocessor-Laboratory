#ifndef _source_INCLUDED_
#define _source_INCLUDED_

#pragma used+

void init();
void q1_name();
void q2_str();
char q3_keypad(char x,char y);
void q5_init();

#pragma used-

#endif

