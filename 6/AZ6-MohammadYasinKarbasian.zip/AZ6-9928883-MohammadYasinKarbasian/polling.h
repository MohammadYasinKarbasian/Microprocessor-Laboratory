#ifndef _polling_INCLUDED_
#define _polling_INCLUDED_

void init_q1();
unsigned int read_adc(unsigned char adc_input);
void q1();
void init();

#endif
