#ifndef _header_INCLUDED_
#define _header_INCLUDED_

#include <image.h>
#include <mega16.h>
#include <delay.h>
#include <glcd.h>
#include <math.h>
#include <font5x7.h>
#include <source.h>

#endif
