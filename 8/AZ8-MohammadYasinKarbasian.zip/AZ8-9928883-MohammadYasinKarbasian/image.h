
#ifndef _IMAGE_INCLUDED_
#define _IMAGE_INCLUDED_

extern flash unsigned char new_image[];

#endif

