#include <header.h>

void main(void)
{
    init();
    q2();
    q1();
    q3();
    while (1)
    {
    }
}
