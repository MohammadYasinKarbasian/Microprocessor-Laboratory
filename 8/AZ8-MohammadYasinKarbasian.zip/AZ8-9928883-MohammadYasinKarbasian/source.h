#ifndef _source_INCLUDED_
#define _source_INCLUDED_

void init();
void q1();
void q2();
void q3();

#endif
