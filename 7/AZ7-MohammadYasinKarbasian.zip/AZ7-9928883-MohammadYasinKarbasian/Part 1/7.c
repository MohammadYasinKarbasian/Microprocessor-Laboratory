#include <header.h>

void main(void)
{

      init();  
      q1();
      while (1)
      {
            
      }
}