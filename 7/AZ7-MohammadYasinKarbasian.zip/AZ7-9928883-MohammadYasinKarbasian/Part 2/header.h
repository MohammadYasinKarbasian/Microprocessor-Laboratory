#ifndef _header_INCLUDED_
#define _header_INCLUDED_

#include <math.h>
#include <stdlib.h>
#include <alcd.h>
#include <delay.h>
#include <mega16.h>
#include <stdio.h>
#include <source.h>

char getchar_nv(void);

#endif