#include <header.h>

void main(void)
{

q3(5,400);

while (1)
      {
          q4(); 
          q5(2348,port_d, port_c);
      }
}
