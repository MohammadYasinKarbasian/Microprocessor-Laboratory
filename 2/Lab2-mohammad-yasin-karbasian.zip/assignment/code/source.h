#ifndef _source_INCLUDED_
#define _source_INCLUDED_

char q1(char in_port);
void q2(char out_port, char data);
void q3(int count, int delay);
void q4();
void q5(int data, char enable_port, char data_port);

#endif